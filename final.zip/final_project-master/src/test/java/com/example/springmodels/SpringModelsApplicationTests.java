package com.example.springmodels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringModelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
